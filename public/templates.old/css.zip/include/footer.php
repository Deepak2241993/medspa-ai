<footer>
    <div class="footer">
        <div class="col-lg-6 col-md-6">
            <p class="mb-0">©2023 ForeverMedspa. All rights reserved.</p>
        </div>
      </div>
      
</footer>
