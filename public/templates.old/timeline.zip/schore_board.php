<?php
   include_once('include/header.php');
   ?>
<div class="containder">
   <div class="page-content   page-min-height  ">
      <div class="container-fluid">
         <div style="opacity: 1; transform: none;">
            
            <div class=" space-y-5">

               <div class="card rounded-md bg-white dark:bg-slate-800   shadow-basecustom-class">
                  <main class="card-body p-6">
                    <h2>Score Board</h2>
                    <div class='col-6'>
                    <form method="post">
                            
                              <div class="md:flex justify-between items-center mb-3">
                              <select class="form-control">
                                 <option value="">..Filter Data..</option>
                                 <option>Search By Down Time2</option>
                                 <option>Search By Down Time3</option>

                              </select>
                             <div class="col-2"> 
                        <button type="submit" class="btn btn-primary">Click me</button>
                        </div>
                        </div>
                           </form>
                        </div>
                     <div class="overflow-x-auto -mx-6">
                        <div class="inline-block min-w-full align-middle">
                           <div class="overflow-hidden ">
                              <table class="min-w-full divide-y divide-slate-100 table-fixed dark:divide-slate-700">
                                 <thead class="bg-slate-200 dark:bg-slate-700">
                                    <tr role="row">
                                       <th colspan="1" role="columnheader" scope="col" class=" table-th ">
                                          <div><input type="checkbox" title="Toggle All Rows Selected" class="table-checkbox" style="cursor: pointer;"></div>
                                          <span></span>
                                       </th>
                                       <th colspan="1" role="columnheader" title="Toggle SortBy" scope="col" class=" table-th " style="cursor: pointer;">Id<span></span></th>
                                       <th colspan="1" role="columnheader" title="Toggle SortBy" scope="col" class=" table-th " style="cursor: pointer;">Name<span></span></th>
                                       <th colspan="1" role="columnheader" title="Toggle SortBy" scope="col" class=" table-th " style="cursor: pointer;">Score<span></span></th>
                                       <th colspan="1" role="columnheader" title="Toggle SortBy" scope="col" class=" table-th " style="cursor: pointer;">Grade<span></span></th>

                                       <th colspan="1" role="columnheader" title="Toggle SortBy" scope="col" class=" table-th " style="cursor: pointer;">action<span></span></th>
                                    </tr>
                                 </thead>
                                 <tbody class="bg-white divide-y divide-slate-100 dark:bg-slate-800 dark:divide-slate-700">
                                    <tr role="row">
                                       <td role="cell" class="table-td">
                                          <div><input type="checkbox" title="Toggle Row Selected" class="table-checkbox" style="cursor: pointer;"></div>
                                       </td>
                                       <td role="cell" class="table-td"><span>1</span></td>
                                       <td role="cell" class="table-td"><span>#951</span></td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                       <td role="cell" class="table-td"><span>
                                          <a type="button" href="timeline.php" class="btn btn-info">Info</a>
                                       </span></td>
                                  
                                    </tr>
                                    <tr role="row">
                                       <td role="cell" class="table-td">
                                          <div><input type="checkbox" title="Toggle Row Selected" class="table-checkbox" style="cursor: pointer;"></div>
                                       </td>
                                       <td role="cell" class="table-td"><span>2</span></td>
                                       <td role="cell" class="table-td"><span>#238</span></td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                    <td role="cell" class="table-td"><span> <a type="button" href="timeline.php" class="btn btn-info">Info</a></span></td>    
                                    </tr>
                                    <tr role="row">
                                       <td role="cell" class="table-td">
                                          <div><input type="checkbox" title="Toggle Row Selected" class="table-checkbox" style="cursor: pointer;"></div>
                                       </td>
                                       <td role="cell" class="table-td"><span>3</span></td>
                                       <td role="cell" class="table-td"><span>#339</span></td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                    <td role="cell" class="table-td"><span> <a type="button" href="timeline.php" class="btn btn-info">Info</a></span></td>    
                                    </tr>
                                    <tr role="row">
                                       <td role="cell" class="table-td">
                                          <div><input type="checkbox" title="Toggle Row Selected" class="table-checkbox" style="cursor: pointer;"></div>
                                       </td>
                                       <td role="cell" class="table-td"><span>4</span></td>
                                       <td role="cell" class="table-td"><span>#365</span></td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                    <td role="cell" class="table-td"><span> <a type="button" href="timeline.php" class="btn btn-info">Info</a></span></td>    
                                    </tr>
                                    <tr role="row">
                                       <td role="cell" class="table-td">
                                          <div><input type="checkbox" title="Toggle Row Selected" class="table-checkbox" style="cursor: pointer;"></div>
                                       </td>
                                       <td role="cell" class="table-td"><span>5</span></td>
                                       <td role="cell" class="table-td"><span>#513</span></td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                    <td role="cell" class="table-td"><span> <a type="button" href="timeline.php" class="btn btn-info">Info</a></span></td>    
                                    </tr>
                                    <tr role="row">
                                       <td role="cell" class="table-td">
                                          <div><input type="checkbox" title="Toggle Row Selected" class="table-checkbox" style="cursor: pointer;"></div>
                                       </td>
                                       <td role="cell" class="table-td"><span>6</span></td>
                                       <td role="cell" class="table-td"><span>#534</span></td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                    <td role="cell" class="table-td"><span> <a type="button" href="timeline.php" class="btn btn-info">Info</a></span></td>    
                                    </tr>
                                    <tr role="row">
                                       <td role="cell" class="table-td">
                                          <div><input type="checkbox" title="Toggle Row Selected" class="table-checkbox" style="cursor: pointer;"></div>
                                       </td>
                                       <td role="cell" class="table-td"><span>7</span></td>
                                       <td role="cell" class="table-td"><span>#77</span></td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                    <td role="cell" class="table-td"><span> <a type="button" href="timeline.php" class="btn btn-info">Info</a></span></td>    
                                    </tr>
                                    <tr role="row">
                                       <td role="cell" class="table-td">
                                          <div><input type="checkbox" title="Toggle Row Selected" class="table-checkbox" style="cursor: pointer;"></div>
                                       </td>
                                       <td role="cell" class="table-td"><span>8</span></td>
                                       <td role="cell" class="table-td"><span>#238</span></td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                    <td role="cell" class="table-td"><span> <a type="button" href="timeline.php" class="btn btn-info">Info</a></span></td>    
                                    </tr>
                                    <tr role="row">
                                       <td role="cell" class="table-td">
                                          <div><input type="checkbox" title="Toggle Row Selected" class="table-checkbox" style="cursor: pointer;"></div>
                                       </td>
                                       <td role="cell" class="table-td"><span>9</span></td>
                                       <td role="cell" class="table-td"><span>#886</span></td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                    <td role="cell" class="table-td"><span> <a type="button" href="timeline.php" class="btn btn-info">Info</a></span></td>    
                                    </tr>
                                    <tr role="row">
                                       <td role="cell" class="table-td">
                                          <div><input type="checkbox" title="Toggle Row Selected" class="table-checkbox" style="cursor: pointer;"></div>
                                       </td>
                                       <td role="cell" class="table-td"><span>10</span></td>
                                       <td role="cell" class="table-td"><span>#3</span></td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                       <td role="cell" class="table-td">
                                          <div>Score</span></div>
                                       </td>
                                    <td role="cell" class="table-td"><span> <a type="button" href="timeline.php" class="btn btn-info">Info</a></span></td>    
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                     
                  </main>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php 
   include_once('include/footer.php');
   ?>
<script src="css/js/jquery.min.js"></script>
<script src="css/js/popper.min.js"></script>
<script src="css/js/bootstrap.min.js"></script>
<script src="css/js/cleave.min.js"></script>
<script src="css/js/main.js"></script>

<script>
// credit card 
var cleaveCreditCard = new Cleave(".input-credit-card", {
  creditCard: true,
  onCreditCardTypeChanged: function(type) {
    type = type.split("15")[0];
    $('.input-with-ccicon #ccicon').removeClass();
    if(type!="unknown"){
        if(type=="diners"){
            $('.input-with-ccicon #ccicon').addClass('fab fa-cc-diners-club');
        }else{
            $('.input-with-ccicon #ccicon').addClass('fab fa-cc-'+type);
        }
    }
  }
});
</script>

</body>
</html>