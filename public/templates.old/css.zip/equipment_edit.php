<?php
   include_once('include/header.php');
   ?>
    <div class="container">
    <h3>Equipment Selection Form</h3>
    
    <form id="equipmentForm">
        <div class="row">
            <div class="col-md-6 col-sm-12 col-lg-6 mt-2">
                <label for="companySelect">Select Company:</label>
                <select id="companySelect" onchange="populatePlatform()" class="form-control">
                    <option value="">Select a Company</option>
                    <!-- Add company options here -->
                    <option value="company1">Company 1</option>
                    <option value="company2">Company 2</option>
                    <option value="company3">Company 3</option>
                </select>
            </div>
                
            <div class="col-md-6 col-sm-12 col-lg-6 mt-2">
                <label for="platformSelect">Select Platform:</label>
                <select id="platformSelect" onchange="populateHandpiece()" class="form-control">
                    <option value="">Select a Platform</option>
                    <!-- Platform options will be dynamically populated based on the selected company -->
                </select>
            </div>
                
            <div class="col-md-6 col-sm-12 col-lg-6 mt-2">
                <label for="handpieceSelect">Select Handpiece:</label>
                <select id="handpieceSelect" onchange="populateModality()" class="form-control">
                    <option value="">Select a Handpiece</option>
                    <!-- Handpiece options will be dynamically populated based on the selected platform -->
                </select>
            </div>
                
            <div class="col-md-6 col-sm-12 col-lg-6 mt-2">
                <label for="modalitySelect">Select Modality:</label>
                <select id="modalitySelect" class="form-control">
                    <option value="">Select a Modality</option>
                    <!-- Modality options will be dynamically populated based on the selected handpiece -->
                </select>
            </div>
        </div>
    </form>
</div>
    <?php 
   include_once('include/footer.php');
   ?>

<script src="css/js/jquery.min.js"></script>
<script src="css/js/popper.min.js"></script>
<script src="css/js/bootstrap.min.js"></script>
<script src="css/js/cleave.min.js"></script>
<script src="css/js/main.js"></script>
    <script>
        // Sample data for platforms, handpieces, and modalities (Replace these with your actual data)
        const platformOptions = {
            company1: ["Platform 1A", "Platform 1B", "Platform 1C"],
            company2: ["Platform 2A", "Platform 2B", "Platform 2C"],
            company3: ["Platform 3A", "Platform 3B", "Platform 3C"]
        };

        const handpieceOptions = {
            "Platform 1A": ["Handpiece 1A1", "Handpiece 1A2", "Handpiece 1A3"],
            "Platform 1B": ["Handpiece 1B1", "Handpiece 1B2", "Handpiece 1B3"],
            "Platform 1C": ["Handpiece 1C1", "Handpiece 1C2", "Handpiece 1C3"],
            "Platform 2A": ["Handpiece 2A1", "Handpiece 2A2", "Handpiece 2A3"],
            "Platform 2B": ["Handpiece 2B1", "Handpiece 2B2", "Handpiece 2B3"],
            "Platform 2C": ["Handpiece 2C1", "Handpiece 2C2", "Handpiece 2C3"],
            "Platform 3A": ["Handpiece 3A1", "Handpiece 3A2", "Handpiece 3A3"],
            "Platform 3B": ["Handpiece 3B1", "Handpiece 3B2", "Handpiece 3B3"],
            "Platform 3C": ["Handpiece 3C1", "Handpiece 3C2", "Handpiece 3C3"]
        };

        const modalityOptions = {
            "Handpiece 1A1": ["Modality A1", "Modality A2", "Modality A3"],
            "Handpiece 1A2": ["Modality B1", "Modality B2", "Modality B3"],
            "Handpiece 1A3": ["Modality C1", "Modality C2", "Modality C3"],
            "Handpiece 1B1": ["Modality D1", "Modality D2", "Modality D3"],
            "Handpiece 1B2": ["Modality E1", "Modality E2", "Modality E3"],
            "Handpiece 1B3": ["Modality F1", "Modality F2", "Modality F3"],
            "Handpiece 1C1": ["Modality G1", "Modality G2", "Modality G3"],
            "Handpiece 1C2": ["Modality H1", "Modality H2", "Modality H3"],
            "Handpiece 1C3": ["Modality I1", "Modality I2", "Modality I3"],
            "Handpiece 2A1": ["Modality J1", "Modality J2", "Modality J3"],
            "Handpiece 2A2": ["Modality K1", "Modality K2", "Modality K3"],
            "Handpiece 2A3": ["Modality L1", "Modality L2", "Modality L3"],
            "Handpiece 2B1": ["Modality M1", "Modality M2", "Modality M3"],
            "Handpiece 2B2": ["Modality N1", "Modality N2", "Modality N3"],
            "Handpiece 2B3": ["Modality O1", "Modality O2", "Modality O3"],
            "Handpiece 2C1": ["Modality P1", "Modality P2", "Modality P3"],
            "Handpiece 2C2": ["Modality Q1", "Modality Q2", "Modality Q3"],
            "Handpiece 2C3": ["Modality R1", "Modality R2", "Modality R3"],
            "Handpiece 3A1": ["Modality S1", "Modality S2", "Modality S3"],
            "Handpiece 3A2": ["Modality T1", "Modality T2", "Modality T3"],
            "Handpiece 3A3": ["Modality U1", "Modality U2", "Modality U3"],
            "Handpiece 3B1": ["Modality V1", "Modality V2", "Modality V3"],
            "Handpiece 3B2": ["Modality W1", "Modality W2", "Modality W3"],
            "Handpiece 3B3": ["Modality X1", "Modality X2", "Modality X3"],
            "Handpiece 3C1": ["Modality Y1", "Modality Y2", "Modality Y3"],
            "Handpiece 3C2": ["Modality Z1", "Modality Z2", "Modality Z3"],
            "Handpiece 3C3": ["Modality AA1", "Modality AA2", "Modality AA3"]
        };

        function populatePlatform() {
            const companySelect = document.getElementById("companySelect");
            const platformSelect = document.getElementById("platformSelect");
            const selectedCompany = companySelect.value;

            // Clear existing options
            platformSelect.innerHTML = "<option value=''>Select a Platform</option>";

            if (selectedCompany in platformOptions) {
                // Populate platform options based on the selected company
                platformOptions[selectedCompany].forEach(platform => {
                    const option = document.createElement("option");
                    option.text = platform;
                    option.value = platform;
                    platformSelect.appendChild(option);
                });
            }
        }

        function populateHandpiece() {
            const platformSelect = document.getElementById("platformSelect");
            const handpieceSelect = document.getElementById("handpieceSelect");
            const selectedPlatform = platformSelect.value;

            // Clear existing options
            handpieceSelect.innerHTML = "<option value=''>Select a Handpiece</option>";

            if (selectedPlatform in handpieceOptions) {
                // Populate handpiece options based on the selected platform
                handpieceOptions[selectedPlatform].forEach(handpiece => {
                    const option = document.createElement("option");
                    option.text = handpiece;
                    option.value = handpiece;
                    handpieceSelect.appendChild(option);
                });
            }
        }

        function populateModality() {
            const handpieceSelect = document.getElementById("handpieceSelect");
            const modalitySelect = document.getElementById("modalitySelect");
            const selectedHandpiece = handpieceSelect.value;

            // Clear existing options
            modalitySelect.innerHTML = "<option value=''>Select a Modality</option>";

            if (selectedHandpiece in modalityOptions) {
                // Populate modality options based on the selected handpiece
                modalityOptions[selectedHandpiece].forEach(modality => {
                    const option = document.createElement("option");
                    option.text = modality;
                    option.value = modality;
                    modalitySelect.appendChild(option);
                });
            }
        }
    </script>
</body>
</html>
